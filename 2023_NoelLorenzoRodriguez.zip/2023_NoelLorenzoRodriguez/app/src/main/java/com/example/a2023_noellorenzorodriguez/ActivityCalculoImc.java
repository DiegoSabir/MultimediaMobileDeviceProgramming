package com.example.a2023_noellorenzorodriguez;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

public class ActivityCalculoImc extends AppCompatActivity {
    EditText etAltura, etPeso;
    Button btnCalcular, btnFinApp;
    ToggleButton tbtnSist;
    boolean sistMet=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_imc);
        etAltura=findViewById(R.id.etAltura);
        etPeso=findViewById(R.id.etPeso);
        btnCalcular=findViewById(R.id.btnCalcular);
        btnFinApp=findViewById(R.id.btnFinApp);
        tbtnSist=findViewById(R.id.tbtnSist);

        btnCalcular.setOnClickListener(escuchadorCalcular);
        btnFinApp.setOnClickListener(escuchadorFin);
        tbtnSist.setOnClickListener(escuchadorSist);
    }

    private View.OnClickListener escuchadorCalcular = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(etAltura.getText().toString().equals("") || etPeso.getText().toString().equals("")){
                Toast.makeText(ActivityCalculoImc.this, R.string.introduceDatos, Toast.LENGTH_SHORT).show();
            }
            else {
                double altura = Double.parseDouble(etAltura.getText().toString());
                double peso = Double.parseDouble(etPeso.getText().toString());
                if (altura==0){
                    Toast.makeText(ActivityCalculoImc.this, R.string.datosIncorrectos, Toast.LENGTH_SHORT).show();
                }
                else {
                    double imc;
                    if (sistMet) {
                        imc = peso / (altura * altura);
                    }
                    else {
                        imc = peso / (altura * altura) * 703;
                    }
                    imc = Math.round(imc * 100) / 100.0;
                    //crear objeto Intent
                    Intent intent = new Intent(ActivityCalculoImc.this, ActivityResultado.class);
                    intent.putExtra("imc", imc);
                    //realizar la llamada
                    startActivity(intent);
                }
            }
        }
    };

    private View.OnClickListener escuchadorFin = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //volver a la MainActivity enviando un dato
            String datoRespuesta="FIN APP";
            Intent intent = new Intent();
            intent.putExtra("respuesta", datoRespuesta);
            setResult(RESULT_OK, intent);
            finish();
        }
    };

    private View.OnClickListener escuchadorSist = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (tbtnSist.isChecked()){
                sistMet=false;
                etAltura.setHint(R.string.pulgadas);
                etPeso.setHint(R.string.libras);
            }
            else {
                sistMet=true;
                etAltura.setHint(R.string.metros);
                etPeso.setHint(R.string.kilos);
            }
        }
    };
}