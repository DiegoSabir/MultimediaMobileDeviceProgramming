package com.example.a2023_noellorenzorodriguez;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final int CODIGO_LLAMADA_ACT_CALCULOIMC=0;
    boolean calculo = true;
    View ivLogo;
    LinearLayout llImc;
    RadioGroup rgOpcion;
    Button btnOpcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivLogo=findViewById(R.id.ivLogo);
        llImc=findViewById(R.id.llImc);
        rgOpcion=findViewById(R.id.rgOpcion);
        btnOpcion=findViewById(R.id.btnOpcion);
        btnOpcion.setText(getResources().getString(R.string.calcularImc).toUpperCase());

        ivLogo.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                ivLogo.setVisibility(View.GONE);
                llImc.setVisibility(View.VISIBLE);
                return false;
            }
        });
        rgOpcion.setOnCheckedChangeListener(escuchadorOpcion);
        btnOpcion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (calculo){
                    Intent intent = new Intent(MainActivity.this, ActivityCalculoImc.class);
                    //llamada esperando respuesta
                    startActivityForResult(intent, CODIGO_LLAMADA_ACT_CALCULOIMC);
                }
                else {
                    //crear objeto Intent
                    Intent intent = new Intent(MainActivity.this, ActivityMasInfo.class);
                    //realizar la llamada
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==CODIGO_LLAMADA_ACT_CALCULOIMC){
            //testeamos codigo de resultado
            if(resultCode==RESULT_OK){
                //actividad llamada finaliza según lo previsto
                finish();
            }
        }
    }

    private RadioGroup.OnCheckedChangeListener escuchadorOpcion = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
            if(checkedId==R.id.rbImc){
                btnOpcion.setText(getResources().getString(R.string.calcularImc).toUpperCase());
                calculo = true;
            }
            else{
                btnOpcion.setText(getResources().getString(R.string.info).toUpperCase());
                calculo = false;
            }
        }
    };
}