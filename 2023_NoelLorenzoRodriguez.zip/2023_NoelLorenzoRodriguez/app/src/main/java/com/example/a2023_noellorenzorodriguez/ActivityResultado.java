package com.example.a2023_noellorenzorodriguez;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ActivityResultado extends AppCompatActivity {
    TextView tvImc, tvTipoImc;
    ImageView ivImc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        tvImc = findViewById(R.id.tvImc);
        tvTipoImc = findViewById(R.id.tvTipoImc);
        ivImc = findViewById(R.id.ivImc);

        //recuperar dato enviado desde MainActivity mediante el Intent
        Intent intent=getIntent();
        //extraer el dato
        double imc = intent.getDoubleExtra("imc", 0);
        //Visualizar dato en TextView
        tvImc.setText("IMC = "+imc);
        if(imc<25){
            ivImc.setImageResource(R.drawable.imc_correcto);
            tvTipoImc.setText(getResources().getString(R.string.imcNormal));
        }
        else if (imc<30){
            ivImc.setImageResource(R.drawable.imc_sobrepeso);
            tvTipoImc.setText(getResources().getString(R.string.imcSobrePeso));
        }
        else {
            ivImc.setImageResource(R.drawable.imc_obesidad);
            tvTipoImc.setText(getResources().getString(R.string.imcObesidad));
        }
    }
}